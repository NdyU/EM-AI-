To compile:
  javac main.java

To Run:
  java main param1 param2

  -param1: the input data file for the table
  -param2: the output file, it will store count the iterations and the likelihood of each iterations

  Example:
    java main data_10.txt out1


To change the starting parameters, go in the main.java file,
go down to the model and modify the values for the probability table
